package reverse;

import java.util.StringJoiner;

public class LinkedList<T> {

    private static class Node<E> {
        E elem;
        Node<E> next;

        Node(E elem) {
            this.elem = elem;
            this.next = null;
        }
    }

    private Node<T> first;

    // DO NOT MODIFY CODE ABOVE
    // Please, fill in your data
    //
    // Surname, Name:
    // Group:

    public void reverse() {
        Node<T> curr = first;
        Node<T> sig = null;
        Node<T> ant = null;
        while(curr != null){
            sig=curr.next; //Muevo al siguiente nodo
            curr.next = ant; //puntero hacia atras
            ant=curr; //Muevo el ant al curr
            curr = sig; //muevo el curr alante (equivalente al curr=curr.next si tuvieramos el puntero)
        }
        first=ant; //pq curr y sig estaran a null

    }

    // DO NOT MODIFY CODE BELOW

    public static LinkedList<Integer> testList() {
        LinkedList<Integer> list = new LinkedList<>();
        Node<Integer> node = new Node<>(0);
        list.first = node;
        for (int i = 1; i < 10; i++) {
            node.next = new Node<>(i);
            node = node.next;
        }
        return list;
    }

    @Override
    public String toString() {
        StringJoiner sj = new StringJoiner(",", "LinkedList(", ")");
        for (Node<T> node = first; node != null; node = node.next)
            sj.add(node.elem.toString());
        return sj.toString();
    }
}
