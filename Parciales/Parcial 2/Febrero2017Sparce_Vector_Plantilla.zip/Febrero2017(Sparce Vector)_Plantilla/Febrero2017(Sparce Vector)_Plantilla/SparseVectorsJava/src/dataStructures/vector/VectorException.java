package dataStructures.vector;

@SuppressWarnings("serial")
public class VectorException extends RuntimeException {

    public VectorException(String message) {
        super(message);
    }
}
